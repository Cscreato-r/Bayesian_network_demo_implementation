# Bayesian Networks — Modelling, Problem Representation & Inference

---

## Overview

This project explores **Bayesian Networks (BNs)** as a framework for probabilistic reasoning under uncertainty. The implementation covers three core aspects of the assignment:

1. **Modelling** — constructing a directed acyclic graph (DAG) from domain knowledge  
2. **Problem Representation** — encoding conditional probability tables (CPTs) from domain priors  
3. **Inference** — computing posterior probabilities via the Variable Elimination algorithm

The chosen example domain is **Medical Diagnosis**: reasoning about whether a patient has Flu or COVID-19 given observed symptoms.

---

## Chosen Example: Medical Diagnosis

### Why this domain?

Medical diagnosis is a canonical application of Bayesian reasoning. Doctors naturally think probabilistically: *"Given this patient's symptoms, what is the most likely cause?"* This maps directly to Bayesian inference — computing P(Disease | Symptoms).

### Network Structure

```
      ┌─────────┐          ┌───────────┐
      │   Flu   │          │   COVID   │
      └────┬────┘          └─────┬─────┘
           │   ╲          ╱      │
           │    ▼        ▼       │
           │   ┌──────────────┐  │
           ├──►│    Fever     │◄─┤
           │   └──────────────┘  │
           │   ┌──────────────┐  │
           ├──►│    Cough     │◄─┤
           │   └──────────────┘  │
           │   ┌──────────────┐  │
           └──►│   Fatigue    │◄─┘
               └──────────────┘
                               ┌──────────────────┐
                               │    Breathing     │◄─ COVID only
                               └──────────────────┘
```

### Variables and Domains

| Variable    | Domain         | Description                                  |
|-------------|----------------|----------------------------------------------|
| `Flu`       | {True, False}  | Patient has influenza                        |
| `COVID`     | {True, False}  | Patient has COVID-19                         |
| `Fever`     | {True, False}  | Patient has fever (> 38°C)                   |
| `Cough`     | {True, False}  | Patient has persistent cough                 |
| `Fatigue`   | {True, False}  | Patient has significant fatigue              |
| `Breathing` | {True, False}  | Patient has breathing difficulty (COVID sign)|

### CPT Design Rationale

The conditional probabilities were designed to reflect real-world epidemiology:

- **Prior prevalence**: Flu ~5%, COVID ~2% in general population
- **Fever**: Both diseases cause fever; COVID has a strong independent contribution (~90%)
- **Breathing difficulty**: Almost exclusively a COVID symptom (60% given COVID, 2% otherwise)
- The `Breathing` variable acts as a **diagnostic discriminator** between Flu and COVID

---

## Tools and Technologies

### Libraries Explored

| Tool | Purpose | Notes |
|------|---------|-------|
| `pgmpy` | BN modelling & inference | Industry standard; explored for reference |
| `bnlearn` | BN structure learning | Wraps pgmpy with simpler API |
| `pomegranate` | Probabilistic modelling | GPU-accelerated BNs |
| **Custom (this project)** | Full from-scratch implementation | Chosen to demonstrate deep understanding |

> **Design choice**: Rather than using a library as a black box, this project implements the BN engine from scratch. This demonstrates understanding of the underlying mathematics — Factor operations, variable elimination, and the chain rule of probability.

### Algorithms Implemented

#### 1. Factor Algebra
The `Factor` class implements:
- **Restriction** (evidence instantiation): fix a variable to an observed value
- **Factor Product**: φ₁(X, Y) × φ₂(Y, Z) = φ(X, Y, Z)
- **Marginalisation** (summing out): Σ_Y φ(X, Y) = φ'(X)
- **Normalisation**: φ → φ / Σ φ

#### 2. Variable Elimination (Exact Inference)
The `query()` method computes P(Q | e) using the variable elimination algorithm:

```
1. Initialise factors from all CPTs
2. Restrict each factor by observed evidence e
3. For each variable Z not in {Q} ∪ evidence:
     a. Collect all factors mentioning Z
     b. Multiply them into a product factor
     c. Sum out Z (marginalise)
4. Multiply remaining factors
5. Normalise to obtain P(Q | e)
```

This is **exact inference** with exponential worst-case complexity, but tractable for networks with low treewidth.

---

## Key Inference Results

### Prior Probabilities (no evidence)
```
P(Flu=True)   = 0.0500   (5% base rate)
P(COVID=True) = 0.0200   (2% base rate)
```

### Posterior After Observing Fever
```
P(Flu=True  | Fever=True) = 0.5439  ↑ from 5%
P(COVID=True| Fever=True) = 0.2305  ↑ from 2%
```
Both diseases are updated upwards — Flu more strongly since it is more prevalent.

### Posterior After Observing All 4 Symptoms
```
P(COVID=True | Fever, Cough, Fatigue, Breathing) = 0.9292  ← strong evidence
P(Flu=True   | Fever, Cough, Fatigue, Breathing) = 0.1279
```
The `Breathing` symptom is **highly discriminative** — observing it dramatically shifts probability toward COVID.

### Effect of Ruling Out Breathing Difficulty
```
P(COVID=True | Fever, Cough, Breathing=False) = 0.1515  ← drops significantly
```
This demonstrates **explaining away** and the BN's ability to reason from negative evidence.

---

## Project Structure

```
bayesian_network/
├── src/
│   ├── bayesian_network.py   # Core BN engine (Factor + BayesianNetwork classes)
│   ├── medical_diagnosis.py  # Network construction + inference demo
│   └── visualise.py          # Figures: DAG, CPT heatmaps, posteriors, sensitivity
├── tests/
│   └── test_bayesian_network.py  # 11 unit tests
├── outputs/
│   ├── fig1_dag.png          # Network structure diagram
│   ├── fig2_cpt_heatmaps.png # CPT visualisation
│   ├── fig3_posteriors.png   # Posterior bar charts under 6 scenarios
│   └── fig4_sensitivity.png  # Sensitivity analysis
└── README.md
```

---

## How to Run

### Requirements
```bash
pip install numpy matplotlib networkx scipy
```
*(No specialised BN library required — everything is implemented from scratch)*

### Run the Inference Demo
```bash
python src/medical_diagnosis.py
```
Prints all 10 inference queries with explanations.

### Generate Figures
```bash
python src/visualise.py
```
Saves 4 figures to `outputs/`.

### Run Tests
```bash
python tests/test_bayesian_network.py
```
Runs 11 unit tests covering Factor algebra, a classic BN (Burglary-Alarm), and the Medical BN.

---

## Theoretical Background

### Bayesian Networks — Formal Definition

A Bayesian Network is a pair (G, Θ) where:
- **G = (V, E)** is a DAG with variables V and directed edges E
- **Θ** = {P(Xᵢ | Pa(Xᵢ))} is a set of CPTs, one per variable

The **joint distribution** factorises as:

```
P(X₁, X₂, …, Xₙ) = ∏ᵢ P(Xᵢ | Pa(Xᵢ))
```

This factorisation embeds **conditional independence** assumptions via d-separation on the DAG.

### Types of Inference

| Type | Query | Example |
|------|-------|---------|
| **Diagnostic** | P(cause \| effect) | P(COVID \| symptoms) |
| **Predictive** | P(effect \| cause) | P(Fever \| COVID=True) |
| **Inter-causal** | P(cause₁ \| cause₂, effect) | P(Flu \| COVID=False, Fever) |
| **Mixed** | Combination | Any multi-variable query |

This implementation supports all four through the general variable elimination interface.

### Comparison with Other Approaches

| Method | Exact? | Scales to? | Notes |
|--------|--------|------------|-------|
| Variable Elimination | ✓ | ~20 variables | Implemented here |
| Junction Tree | ✓ | ~30 variables | Better for repeated queries |
| MCMC Sampling | ✗ (approx) | Hundreds of vars | Standard for large networks |
| Loopy Belief Prop | ✗ (approx) | Thousands of vars | Used in modern ML |

---

## Discussion

### What Works Well
- The BN correctly captures **explaining away**: observing that a patient does NOT have breathing difficulty significantly reduces COVID probability even when other symptoms are present
- The network is **modular** — any CPT can be updated without changing the inference algorithm
- The sensitivity analysis (Fig 4) shows the model is robust: posterior rises monotonically as P(Breathing | COVID) increases, behaving as expected

### Limitations
- Small network — real diagnostic BNs have hundreds of variables
- CPT values are hand-crafted from domain priors, not learned from data
- Variable Elimination ordering is not optimised (min-fill heuristic would help)

### Extensions
- **Structure learning** from patient data using score-based methods (BIC, MDL)
- **Parameter learning** using Maximum Likelihood Estimation or EM
- **Approximate inference** via MCMC for larger disease networks
- Adding **temporal** structure (Dynamic BN) for disease progression over time

---

## References

1. Russell, S. & Norvig, P. (2021). *Artificial Intelligence: A Modern Approach* (4th ed.). Chapters 12–13.
2. Koller, D. & Friedman, N. (2009). *Probabilistic Graphical Models*. MIT Press.
3. Pearl, J. (1988). *Probabilistic Reasoning in Intelligent Systems*. Morgan Kaufmann.
4. Darwiche, A. (2009). *Modeling and Reasoning with Bayesian Networks*. Cambridge University Press.
5. Murphy, K. (2012). *Machine Learning: A Probabilistic Perspective*. MIT Press.

