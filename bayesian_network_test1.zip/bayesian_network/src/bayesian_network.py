"""
bayesian_network.py
-------------------
A from-scratch Bayesian Network implementation covering:
  - DAG structure modelling
  - Conditional Probability Table (CPT) representation
  - Exact inference via Variable Elimination
  - Prior / posterior query interface

Author : [Student]
Date   : May 2026
"""

import itertools
import numpy as np
from collections import defaultdict
from typing import Dict, List, Optional, Tuple


# ─────────────────────────────────────────────────────────────────────────────
# Factor  –  the fundamental building block
# ─────────────────────────────────────────────────────────────────────────────

class Factor:
    """
    Represents a factor φ(X₁, X₂, …, Xₙ).

    Internally stores a numpy array whose axes correspond to the variables
    listed in `variables`, in order.  The domain of each variable gives the
    size of its axis.
    """

    def __init__(self, variables: List[str], domains: Dict[str, List],
                 values: np.ndarray):
        self.variables = list(variables)
        self.domains   = {v: list(domains[v]) for v in variables}
        self.values    = np.array(values, dtype=float)

        expected_shape = tuple(len(domains[v]) for v in variables)
        if self.values.shape != expected_shape:
            self.values = self.values.reshape(expected_shape)

    # ── helpers ──────────────────────────────────────────────────────────────

    def _idx(self, var: str, val) -> int:
        return self.domains[var].index(val)

    def _assignment_to_index(self, assignment: Dict[str, any]) -> Tuple:
        return tuple(self._idx(v, assignment[v]) for v in self.variables)

    # ── operations ────────────────────────────────────────────────────────────

    def get(self, assignment: Dict[str, any]) -> float:
        return float(self.values[self._assignment_to_index(assignment)])

    def restrict(self, var: str, val) -> "Factor":
        """Return a new factor with `var` fixed to `val`."""
        axis = self.variables.index(var)
        idx  = self._idx(var, val)
        new_values = np.take(self.values, idx, axis=axis)
        new_vars   = [v for v in self.variables if v != var]
        new_domains = {v: self.domains[v] for v in new_vars}
        return Factor(new_vars, new_domains, new_values)

    def multiply(self, other: "Factor") -> "Factor":
        """Factor product."""
        # union of variables, preserving order
        all_vars = list(self.variables)
        for v in other.variables:
            if v not in all_vars:
                all_vars.append(v)

        all_domains = {}
        for v in all_vars:
            if v in self.domains:
                all_domains[v] = self.domains[v]
            else:
                all_domains[v] = other.domains[v]

        shape = tuple(len(all_domains[v]) for v in all_vars)
        result = np.zeros(shape)

        for assignment in _all_assignments(all_vars, all_domains):
            a_self  = {v: assignment[v] for v in self.variables}
            a_other = {v: assignment[v] for v in other.variables}
            idx = tuple(all_domains[v].index(assignment[v]) for v in all_vars)
            result[idx] = self.get(a_self) * other.get(a_other)

        return Factor(all_vars, all_domains, result)

    def marginalise(self, var: str) -> "Factor":
        """Sum out `var`."""
        axis       = self.variables.index(var)
        new_values = self.values.sum(axis=axis)
        new_vars   = [v for v in self.variables if v != var]
        new_domains = {v: self.domains[v] for v in new_vars}
        return Factor(new_vars, new_domains, new_values)

    def normalise(self) -> "Factor":
        total = self.values.sum()
        return Factor(self.variables, self.domains, self.values / total)

    def __repr__(self):
        return f"Factor({self.variables})"


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _all_assignments(variables, domains):
    """Yield every combination of values for the given variables."""
    value_lists = [domains[v] for v in variables]
    for combo in itertools.product(*value_lists):
        yield dict(zip(variables, combo))


# ─────────────────────────────────────────────────────────────────────────────
# BayesianNetwork
# ─────────────────────────────────────────────────────────────────────────────

class BayesianNetwork:
    """
    A Bayesian Network consisting of:
      - A directed acyclic graph (DAG) over random variables
      - A conditional probability table (CPT) per node
    """

    def __init__(self):
        self.variables: List[str]            = []
        self.domains:   Dict[str, List]      = {}
        self.parents:   Dict[str, List[str]] = {}
        self.cpts:      Dict[str, Factor]    = {}

    # ── construction ─────────────────────────────────────────────────────────

    def add_variable(self, name: str, domain: List):
        """Register a random variable."""
        if name in self.variables:
            raise ValueError(f"Variable '{name}' already exists.")
        self.variables.append(name)
        self.domains[name] = list(domain)
        self.parents[name] = []

    def add_edge(self, parent: str, child: str):
        """Add a directed edge parent → child."""
        self._assert_exists(parent)
        self._assert_exists(child)
        if parent not in self.parents[child]:
            self.parents[child].append(parent)

    def set_cpt(self, variable: str, cpt_values: np.ndarray):
        """
        Attach a CPT to `variable`.

        `cpt_values` must have shape
            (|domain(parent_1)|, …, |domain(parent_k)|, |domain(variable)|)
        where parents are in the order returned by self.parents[variable].
        """
        self._assert_exists(variable)
        scope    = self.parents[variable] + [variable]
        domains  = {v: self.domains[v] for v in scope}
        self.cpts[variable] = Factor(scope, domains, cpt_values)

    # ── inference  ───────────────────────────────────────────────────────────

    def query(self, query_var: str,
              evidence: Optional[Dict[str, any]] = None) -> Dict:
        """
        Compute P(query_var | evidence) via variable elimination.

        Returns a dict {value: probability}.
        """
        evidence = evidence or {}

        # 1. Start with all CPT factors
        factors = [self.cpts[v].copy() if hasattr(self.cpts[v], 'copy')
                   else Factor(self.cpts[v].variables,
                               self.cpts[v].domains,
                               self.cpts[v].values.copy())
                   for v in self.variables]

        # 2. Restrict factors to observed evidence
        restricted = []
        for f in factors:
            for var, val in evidence.items():
                if var in f.variables:
                    f = f.restrict(var, val)
            restricted.append(f)

        # 3. Elimination order: all variables except query and evidence
        to_eliminate = [v for v in self.variables
                        if v != query_var and v not in evidence]

        active = restricted

        for elim_var in to_eliminate:
            # collect factors that mention elim_var
            relevant = [f for f in active if elim_var in f.variables]
            others   = [f for f in active if elim_var not in f.variables]

            # multiply them together
            product = relevant[0]
            for f in relevant[1:]:
                product = product.multiply(f)

            # sum out elim_var
            marginalised = product.marginalise(elim_var)
            others.append(marginalised)
            active = others

        # 4. Multiply remaining factors and normalise
        result = active[0]
        for f in active[1:]:
            result = result.multiply(f)

        result = result.normalise()

        # 5. Build output dict
        return {val: float(result.get({query_var: val}))
                for val in self.domains[query_var]}

    def joint_probability(self, assignment: Dict[str, any]) -> float:
        """Return P(assignment) using the chain rule."""
        prob = 1.0
        for var in self.variables:
            prob *= self.cpts[var].get(
                {v: assignment[v] for v in self.cpts[var].variables}
            )
        return prob

    # ── utilities ────────────────────────────────────────────────────────────

    def _assert_exists(self, name: str):
        if name not in self.variables:
            raise ValueError(f"Unknown variable '{name}'. "
                             f"Add it first with add_variable().")

    def summary(self):
        print("=" * 55)
        print("  Bayesian Network Summary")
        print("=" * 55)
        for v in self.variables:
            parents_str = ", ".join(self.parents[v]) or "—"
            domain_str  = str(self.domains[v])
            print(f"  {v:20s}  parents={parents_str}")
            print(f"  {'':20s}  domain ={domain_str}")
        print("=" * 55)
