"""
medical_diagnosis.py
--------------------
Example: Medical Diagnosis Bayesian Network
============================================

Domain:
    We model the probability of a patient having a disease (Flu or COVID)
    given observed symptoms (Fever, Cough, Fatigue, Breathing Difficulty).

    The network captures:
      • Base rates of diseases in the population
      • Conditional probabilities of symptoms given each disease
      • Reasoning from symptoms (evidence) back to disease (inference)

Network Structure (DAG):
    ┌──────────┐   ┌───────────┐
    │   Flu    │   │  COVID    │
    └────┬─────┘   └─────┬─────┘
         │               │
    ┌────▼───────────────▼────┐
    │         Fever           │
    └─────────────────────────┘
         │               │
    ┌────▼───────────────▼────┐
    │         Cough           │
    └─────────────────────────┘
    ...

    Simplified as:
      Flu   → {Fever, Cough, Fatigue}
      COVID → {Fever, Cough, Fatigue, Breathing_Difficulty}

Author : [Student]
Date   : May 2026
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

import numpy as np
from bayesian_network import BayesianNetwork


def build_medical_bn() -> BayesianNetwork:
    """
    Construct and return the Medical Diagnosis Bayesian Network.

    Variables
    ---------
    Flu        : {True, False}
    COVID      : {True, False}
    Fever      : {True, False}   — caused by Flu or COVID
    Cough      : {True, False}   — caused by Flu or COVID
    Fatigue    : {True, False}   — caused by Flu or COVID
    Breathing  : {True, False}   — caused mainly by COVID
    """
    bn = BayesianNetwork()

    # ── 1. Register variables ────────────────────────────────────────────────
    bn.add_variable("Flu",       [True, False])
    bn.add_variable("COVID",     [True, False])
    bn.add_variable("Fever",     [True, False])
    bn.add_variable("Cough",     [True, False])
    bn.add_variable("Fatigue",   [True, False])
    bn.add_variable("Breathing", [True, False])

    # ── 2. Add edges ─────────────────────────────────────────────────────────
    bn.add_edge("Flu",   "Fever")
    bn.add_edge("Flu",   "Cough")
    bn.add_edge("Flu",   "Fatigue")
    bn.add_edge("COVID", "Fever")
    bn.add_edge("COVID", "Cough")
    bn.add_edge("COVID", "Fatigue")
    bn.add_edge("COVID", "Breathing")

    # ── 3. Set CPTs ──────────────────────────────────────────────────────────

    # P(Flu): prevalence ~ 5% in general population
    # shape: (2,)  → [P(Flu=T), P(Flu=F)]
    bn.set_cpt("Flu", np.array([0.05, 0.95]))

    # P(COVID): prevalence ~ 2% in general population
    bn.set_cpt("COVID", np.array([0.02, 0.98]))

    # P(Fever | Flu, COVID)
    # Parents order: [Flu, COVID] → shape (2, 2, 2)
    #   axis-0 = Flu   {T, F}
    #   axis-1 = COVID {T, F}
    #   axis-2 = Fever {T, F}
    fever_cpt = np.array([
        # Flu=T
        [
            [0.95, 0.05],   # COVID=T → very likely fever
            [0.85, 0.15],   # COVID=F → flu fever likely
        ],
        # Flu=F
        [
            [0.90, 0.10],   # COVID=T → covid fever likely
            [0.02, 0.98],   # COVID=F → baseline fever rare
        ],
    ])
    bn.set_cpt("Fever", fever_cpt)

    # P(Cough | Flu, COVID)
    cough_cpt = np.array([
        # Flu=T
        [
            [0.90, 0.10],   # COVID=T
            [0.80, 0.20],   # COVID=F
        ],
        # Flu=F
        [
            [0.85, 0.15],   # COVID=T
            [0.10, 0.90],   # COVID=F
        ],
    ])
    bn.set_cpt("Cough", cough_cpt)

    # P(Fatigue | Flu, COVID)
    fatigue_cpt = np.array([
        # Flu=T
        [
            [0.95, 0.05],   # COVID=T
            [0.90, 0.10],   # COVID=F
        ],
        # Flu=F
        [
            [0.85, 0.15],   # COVID=T
            [0.05, 0.95],   # COVID=F
        ],
    ])
    bn.set_cpt("Fatigue", fatigue_cpt)

    # P(Breathing | COVID)
    # Only COVID causes significant breathing difficulty
    breathing_cpt = np.array([
        [0.60, 0.40],   # COVID=T → 60% chance
        [0.02, 0.98],   # COVID=F → rare
    ])
    bn.set_cpt("Breathing", breathing_cpt)

    return bn


def run_queries(bn: BayesianNetwork):
    """
    Run a series of diagnostic queries to demonstrate inference.
    """
    print("\n" + "=" * 60)
    print("  MEDICAL DIAGNOSIS — BAYESIAN NETWORK INFERENCE")
    print("=" * 60)

    # ── Query 1: Prior probabilities ─────────────────────────────────────────
    print("\n[Q1] Prior probability of Flu (no symptoms observed):")
    result = bn.query("Flu")
    for val, prob in result.items():
        print(f"     P(Flu={val}) = {prob:.4f}")

    print("\n[Q2] Prior probability of COVID (no symptoms observed):")
    result = bn.query("COVID")
    for val, prob in result.items():
        print(f"     P(COVID={val}) = {prob:.4f}")

    # ── Query 2: Single symptom evidence ─────────────────────────────────────
    print("\n[Q3] P(Flu | Fever=True):")
    result = bn.query("Flu", evidence={"Fever": True})
    for val, prob in result.items():
        print(f"     P(Flu={val} | Fever=True) = {prob:.4f}")

    print("\n[Q4] P(COVID | Fever=True):")
    result = bn.query("COVID", evidence={"Fever": True})
    for val, prob in result.items():
        print(f"     P(COVID={val} | Fever=True) = {prob:.4f}")

    # ── Query 3: Multiple symptoms ────────────────────────────────────────────
    evidence_mild = {"Fever": True, "Cough": True}
    print(f"\n[Q5] P(Flu | Fever=True, Cough=True):")
    result = bn.query("Flu", evidence=evidence_mild)
    for val, prob in result.items():
        print(f"     P(Flu={val} | ...) = {prob:.4f}")

    print(f"\n[Q6] P(COVID | Fever=True, Cough=True):")
    result = bn.query("COVID", evidence=evidence_mild)
    for val, prob in result.items():
        print(f"     P(COVID={val} | ...) = {prob:.4f}")

    # ── Query 4: COVID hallmark symptom ──────────────────────────────────────
    evidence_severe = {
        "Fever": True, "Cough": True,
        "Fatigue": True, "Breathing": True
    }
    print(f"\n[Q7] P(COVID | Fever, Cough, Fatigue, Breathing=True):")
    result = bn.query("COVID", evidence=evidence_severe)
    for val, prob in result.items():
        print(f"     P(COVID={val} | all symptoms) = {prob:.4f}")

    print(f"\n[Q8] P(Flu | Fever, Cough, Fatigue, Breathing=True):")
    result = bn.query("Flu", evidence=evidence_severe)
    for val, prob in result.items():
        print(f"     P(Flu={val} | all symptoms) = {prob:.4f}")

    # ── Query 5: No breathing difficulty → less likely COVID ─────────────────
    evidence_no_breathing = {
        "Fever": True, "Cough": True, "Breathing": False
    }
    print(f"\n[Q9] P(COVID | Fever, Cough, Breathing=FALSE):")
    result = bn.query("COVID", evidence=evidence_no_breathing)
    for val, prob in result.items():
        print(f"     P(COVID={val} | ...) = {prob:.4f}")

    # ── Query 6: Joint probability ────────────────────────────────────────────
    print("\n[Q10] Joint P(Flu=T, COVID=F, Fever=T, Cough=T, Fatigue=T, Breathing=F):")
    joint = bn.joint_probability({
        "Flu": True, "COVID": False,
        "Fever": True, "Cough": True,
        "Fatigue": True, "Breathing": False
    })
    print(f"      P = {joint:.6f}")

    print("\n" + "=" * 60)
    print("  INFERENCE COMPLETE")
    print("=" * 60)


if __name__ == "__main__":
    bn = build_medical_bn()
    bn.summary()
    run_queries(bn)
