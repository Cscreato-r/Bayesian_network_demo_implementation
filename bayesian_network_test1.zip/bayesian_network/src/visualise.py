"""
visualise.py
------------
Generates publication-quality figures for the Medical Diagnosis BN:
  1. DAG structure diagram
  2. CPT heatmaps
  3. Posterior probability bar charts under different evidence scenarios

Author : [Student]
Date   : May 2026
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch
import networkx as nx

from bayesian_network import BayesianNetwork
from medical_diagnosis import build_medical_bn, run_queries


# ── colour palette ────────────────────────────────────────────────────────────
PALETTE = {
    "bg":        "#0f1117",
    "card":      "#1a1d27",
    "accent1":   "#4f8ef7",   # blue  – Flu
    "accent2":   "#e05c5c",   # red   – COVID
    "accent3":   "#50c878",   # green – symptoms
    "text":      "#e8eaf0",
    "subtext":   "#8890a4",
    "grid":      "#2a2d3a",
}

plt.rcParams.update({
    "figure.facecolor":  PALETTE["bg"],
    "axes.facecolor":    PALETTE["card"],
    "axes.edgecolor":    PALETTE["grid"],
    "axes.labelcolor":   PALETTE["text"],
    "xtick.color":       PALETTE["subtext"],
    "ytick.color":       PALETTE["subtext"],
    "text.color":        PALETTE["text"],
    "grid.color":        PALETTE["grid"],
    "font.family":       "monospace",
})


# ── Figure 1: DAG Structure ───────────────────────────────────────────────────

def plot_dag(save_path: str):
    G = nx.DiGraph()
    edges = [
        ("Flu",   "Fever"),
        ("Flu",   "Cough"),
        ("Flu",   "Fatigue"),
        ("COVID", "Fever"),
        ("COVID", "Cough"),
        ("COVID", "Fatigue"),
        ("COVID", "Breathing"),
    ]
    G.add_edges_from(edges)

    pos = {
        "Flu":       (-1.5, 1.2),
        "COVID":     ( 1.5, 1.2),
        "Fever":     (-1.2, 0),
        "Cough":     ( 0,   0),
        "Fatigue":   ( 1.2, 0),
        "Breathing": ( 2.4, 0),
    }

    node_colors = {
        "Flu":       PALETTE["accent1"],
        "COVID":     PALETTE["accent2"],
        "Fever":     PALETTE["accent3"],
        "Cough":     PALETTE["accent3"],
        "Fatigue":   PALETTE["accent3"],
        "Breathing": PALETTE["accent3"],
    }

    fig, ax = plt.subplots(figsize=(11, 5), facecolor=PALETTE["bg"])
    ax.set_facecolor(PALETTE["bg"])
    ax.set_title("Medical Diagnosis — Bayesian Network DAG",
                 fontsize=14, color=PALETTE["text"], pad=18, fontweight="bold")

    colors = [node_colors[n] for n in G.nodes()]
    nx.draw_networkx(
        G, pos, ax=ax,
        node_color=colors,
        node_size=2800,
        font_size=9,
        font_color="#ffffff",
        font_weight="bold",
        edge_color=PALETTE["subtext"],
        arrowsize=20,
        arrowstyle="-|>",
        width=2,
        connectionstyle="arc3,rad=0.05",
    )

    legend_handles = [
        mpatches.Patch(color=PALETTE["accent1"], label="Disease node (Flu)"),
        mpatches.Patch(color=PALETTE["accent2"], label="Disease node (COVID)"),
        mpatches.Patch(color=PALETTE["accent3"], label="Symptom node"),
    ]
    ax.legend(handles=legend_handles, loc="lower left",
              facecolor=PALETTE["card"], edgecolor=PALETTE["grid"],
              labelcolor=PALETTE["text"], fontsize=9)

    ax.axis("off")
    fig.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=PALETTE["bg"])
    plt.close(fig)
    print(f"  [✓] Saved: {save_path}")


# ── Figure 2: CPT heatmaps ────────────────────────────────────────────────────

def plot_cpt_heatmaps(bn: BayesianNetwork, save_path: str):
    fig, axes = plt.subplots(1, 3, figsize=(15, 4), facecolor=PALETTE["bg"])
    fig.suptitle("Conditional Probability Tables (P=True column)",
                 fontsize=13, color=PALETTE["text"], fontweight="bold", y=1.02)

    symptom_info = {
        "Fever": {
            "rows": ["Flu=T,COV=T", "Flu=T,COV=F",
                     "Flu=F,COV=T", "Flu=F,COV=F"],
            "vals": [0.95, 0.85, 0.90, 0.02],
        },
        "Cough": {
            "rows": ["Flu=T,COV=T", "Flu=T,COV=F",
                     "Flu=F,COV=T", "Flu=F,COV=F"],
            "vals": [0.90, 0.80, 0.85, 0.10],
        },
        "Fatigue": {
            "rows": ["Flu=T,COV=T", "Flu=T,COV=F",
                     "Flu=F,COV=T", "Flu=F,COV=F"],
            "vals": [0.95, 0.90, 0.85, 0.05],
        },
    }

    for ax, (symptom, info) in zip(axes, symptom_info.items()):
        vals  = np.array(info["vals"]).reshape(-1, 1)
        im = ax.imshow(vals, cmap="RdYlGn", vmin=0, vmax=1, aspect="auto")
        ax.set_xticks([0])
        ax.set_xticklabels(["P(True)"])
        ax.set_yticks(range(len(info["rows"])))
        ax.set_yticklabels(info["rows"], fontsize=9)
        ax.set_title(symptom, color=PALETTE["accent3"], fontsize=11,
                     fontweight="bold")
        for i, v in enumerate(info["vals"]):
            ax.text(0, i, f"{v:.2f}", ha="center", va="center",
                    color="white", fontsize=11, fontweight="bold")
        plt.colorbar(im, ax=ax, fraction=0.12, pad=0.04)

    fig.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=PALETTE["bg"])
    plt.close(fig)
    print(f"  [✓] Saved: {save_path}")


# ── Figure 3: Posterior probability bar charts ────────────────────────────────

def plot_posteriors(bn: BayesianNetwork, save_path: str):
    scenarios = [
        ("No evidence (prior)",
         {}),
        ("Fever=True",
         {"Fever": True}),
        ("Fever + Cough",
         {"Fever": True, "Cough": True}),
        ("Fever + Cough + Fatigue",
         {"Fever": True, "Cough": True, "Fatigue": True}),
        ("All 4 symptoms",
         {"Fever": True, "Cough": True, "Fatigue": True, "Breathing": True}),
        ("Fever + Cough, Breathing=False",
         {"Fever": True, "Cough": True, "Breathing": False}),
    ]

    flu_probs   = []
    covid_probs = []

    for label, evidence in scenarios:
        flu_probs.append(bn.query("Flu",   evidence=evidence)[True])
        covid_probs.append(bn.query("COVID", evidence=evidence)[True])

    labels = [s[0] for s in scenarios]
    x = np.arange(len(labels))
    w = 0.35

    fig, ax = plt.subplots(figsize=(13, 5), facecolor=PALETTE["bg"])
    ax.set_facecolor(PALETTE["card"])

    bars1 = ax.bar(x - w/2, flu_probs,   w, label="P(Flu=True)",
                   color=PALETTE["accent1"], alpha=0.88, zorder=3)
    bars2 = ax.bar(x + w/2, covid_probs, w, label="P(COVID=True)",
                   color=PALETTE["accent2"], alpha=0.88, zorder=3)

    for bar in bars1:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2, h + 0.005,
                f"{h:.3f}", ha="center", va="bottom",
                fontsize=7.5, color=PALETTE["accent1"])

    for bar in bars2:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2, h + 0.005,
                f"{h:.3f}", ha="center", va="bottom",
                fontsize=7.5, color=PALETTE["accent2"])

    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=18, ha="right", fontsize=9)
    ax.set_ylabel("Posterior Probability", fontsize=11)
    ax.set_title("Posterior P(Disease | Evidence) — Variable Elimination",
                 fontsize=13, fontweight="bold", color=PALETTE["text"], pad=14)
    ax.set_ylim(0, max(max(flu_probs), max(covid_probs)) * 1.25)
    ax.yaxis.grid(True, linestyle="--", alpha=0.4, zorder=0)
    ax.legend(facecolor=PALETTE["card"], edgecolor=PALETTE["grid"],
              labelcolor=PALETTE["text"], fontsize=10)

    fig.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=PALETTE["bg"])
    plt.close(fig)
    print(f"  [✓] Saved: {save_path}")


# ── Figure 4: Sensitivity analysis ───────────────────────────────────────────

def plot_sensitivity(bn: BayesianNetwork, save_path: str):
    """
    How does P(COVID=True) change as we vary P(Breathing=True | COVID=True)?
    Simulates sensitivity of the posterior to a CPT parameter.
    """
    param_range = np.linspace(0.01, 0.99, 60)
    evidence    = {"Fever": True, "Cough": True, "Fatigue": True,
                   "Breathing": True}

    posteriors = []
    for p_breath_given_covid in param_range:
        # Clone CPT for Breathing
        import copy
        bn2 = copy.deepcopy(bn)
        bn2.cpts["Breathing"].values = np.array([
            [p_breath_given_covid, 1 - p_breath_given_covid],
            [0.02,                  0.98],
        ])
        posteriors.append(bn2.query("COVID", evidence=evidence)[True])

    fig, ax = plt.subplots(figsize=(9, 4), facecolor=PALETTE["bg"])
    ax.set_facecolor(PALETTE["card"])

    ax.plot(param_range, posteriors, color=PALETTE["accent2"],
            linewidth=2.5, zorder=3)
    ax.fill_between(param_range, posteriors, alpha=0.2,
                    color=PALETTE["accent2"], zorder=2)
    ax.axvline(0.60, color=PALETTE["accent1"], linestyle="--",
               linewidth=1.5, label="Default CPT value (0.60)")
    ax.yaxis.grid(True, linestyle="--", alpha=0.4, zorder=0)

    ax.set_xlabel("P(Breathing=True | COVID=True)", fontsize=11)
    ax.set_ylabel("P(COVID=True | all 4 symptoms)", fontsize=11)
    ax.set_title("Sensitivity Analysis — Breathing CPT Parameter",
                 fontsize=13, fontweight="bold", color=PALETTE["text"], pad=14)
    ax.legend(facecolor=PALETTE["card"], edgecolor=PALETTE["grid"],
              labelcolor=PALETTE["text"])

    fig.tight_layout()
    fig.savefig(save_path, dpi=150, bbox_inches="tight",
                facecolor=PALETTE["bg"])
    plt.close(fig)
    print(f"  [✓] Saved: {save_path}")


# ── Main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    out_dir = os.path.join(os.path.dirname(__file__), "..", "outputs")
    os.makedirs(out_dir, exist_ok=True)

    bn = build_medical_bn()

    print("\nGenerating figures …")
    plot_dag(            os.path.join(out_dir, "fig1_dag.png"))
    plot_cpt_heatmaps(bn, os.path.join(out_dir, "fig2_cpt_heatmaps.png"))
    plot_posteriors(bn,   os.path.join(out_dir, "fig3_posteriors.png"))
    plot_sensitivity(bn,  os.path.join(out_dir, "fig4_sensitivity.png"))
    print("\nAll figures saved to outputs/")
