"""
tests/test_bayesian_network.py
-------------------------------
Unit tests for the Bayesian Network core engine.

Run with:   python -m pytest tests/ -v
            (or simply: python tests/test_bayesian_network.py)

Author : [Student]
Date   : May 2026
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import numpy as np
from bayesian_network import BayesianNetwork, Factor


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def approx(a, b, tol=1e-6):
    return abs(a - b) < tol


# ──────────────────────────────────────────────────────────────────────────────
# Factor tests
# ──────────────────────────────────────────────────────────────────────────────

def test_factor_get():
    f = Factor(["X"], {"X": [0, 1]}, np.array([0.3, 0.7]))
    assert approx(f.get({"X": 0}), 0.3)
    assert approx(f.get({"X": 1}), 0.7)
    print("  [✓] test_factor_get")


def test_factor_restrict():
    f = Factor(["X", "Y"],
               {"X": [0, 1], "Y": ["a", "b"]},
               np.array([[0.1, 0.2], [0.3, 0.4]]))
    r = f.restrict("X", 1)
    assert r.variables == ["Y"]
    assert approx(r.get({"Y": "a"}), 0.3)
    assert approx(r.get({"Y": "b"}), 0.4)
    print("  [✓] test_factor_restrict")


def test_factor_multiply():
    f1 = Factor(["X"], {"X": ["T", "F"]}, np.array([0.4, 0.6]))
    f2 = Factor(["Y"], {"Y": ["T", "F"]}, np.array([0.7, 0.3]))
    prod = f1.multiply(f2)
    assert set(prod.variables) == {"X", "Y"}
    assert approx(prod.get({"X": "T", "Y": "T"}), 0.28)
    assert approx(prod.get({"X": "F", "Y": "F"}), 0.18)
    print("  [✓] test_factor_multiply")


def test_factor_marginalise():
    f = Factor(["X", "Y"],
               {"X": [0, 1], "Y": [0, 1]},
               np.array([[0.1, 0.2], [0.3, 0.4]]))
    m = f.marginalise("Y")
    assert m.variables == ["X"]
    assert approx(m.get({"X": 0}), 0.3)   # 0.1+0.2
    assert approx(m.get({"X": 1}), 0.7)   # 0.3+0.4
    print("  [✓] test_factor_marginalise")


def test_factor_normalise():
    f = Factor(["X"], {"X": [0, 1]}, np.array([2.0, 6.0]))
    n = f.normalise()
    assert approx(n.get({"X": 0}), 0.25)
    assert approx(n.get({"X": 1}), 0.75)
    print("  [✓] test_factor_normalise")


# ──────────────────────────────────────────────────────────────────────────────
# Simple BN: Burglary → Alarm ← Earthquake
# Classic textbook example (AIMA)
# ──────────────────────────────────────────────────────────────────────────────

def build_simple_bn():
    bn = BayesianNetwork()
    bn.add_variable("Burglary",   [True, False])
    bn.add_variable("Earthquake", [True, False])
    bn.add_variable("Alarm",      [True, False])

    bn.add_edge("Burglary",   "Alarm")
    bn.add_edge("Earthquake", "Alarm")

    bn.set_cpt("Burglary",   np.array([0.001, 0.999]))
    bn.set_cpt("Earthquake", np.array([0.002, 0.998]))

    # P(Alarm | Burglary, Earthquake)
    # shape: (2, 2, 2)  — B, E, A
    alarm_cpt = np.array([
        [[0.95, 0.05], [0.94, 0.06]],   # B=T
        [[0.29, 0.71], [0.001, 0.999]], # B=F
    ])
    bn.set_cpt("Alarm", alarm_cpt)
    return bn


def test_prior_query():
    bn = build_simple_bn()
    result = bn.query("Burglary")
    assert approx(result[True],  0.001)
    assert approx(result[False], 0.999)
    print("  [✓] test_prior_query")


def test_posterior_sums_to_one():
    bn = build_simple_bn()
    result = bn.query("Burglary", evidence={"Alarm": True})
    total = sum(result.values())
    assert approx(total, 1.0), f"Sum = {total}"
    print("  [✓] test_posterior_sums_to_one")


def test_alarm_evidence_raises_burglary():
    bn = build_simple_bn()
    prior = bn.query("Burglary")[True]
    posterior = bn.query("Burglary", evidence={"Alarm": True})[True]
    assert posterior > prior, \
        f"Posterior {posterior:.4f} should exceed prior {prior:.4f}"
    print("  [✓] test_alarm_evidence_raises_burglary")


def test_joint_probability():
    bn = build_simple_bn()
    # P(B=T, E=F, A=T)
    jp = bn.joint_probability({
        "Burglary": True, "Earthquake": False, "Alarm": True
    })
    # Manual: 0.001 * 0.998 * 0.94 = 0.000938...
    expected = 0.001 * 0.998 * 0.94
    assert approx(jp, expected, tol=1e-8), f"Got {jp}, expected {expected}"
    print("  [✓] test_joint_probability")


# ──────────────────────────────────────────────────────────────────────────────
# Medical BN tests
# ──────────────────────────────────────────────────────────────────────────────

def test_medical_breathing_increases_covid():
    from medical_diagnosis import build_medical_bn
    bn = build_medical_bn()
    prior    = bn.query("COVID")[True]
    post_yes = bn.query("COVID", evidence={"Breathing": True})[True]
    post_no  = bn.query("COVID", evidence={"Breathing": False})[True]
    assert post_yes > prior > post_no, \
        "Breathing=True should raise COVID probability"
    print("  [✓] test_medical_breathing_increases_covid")


def test_medical_all_symptoms_covid_dominant():
    from medical_diagnosis import build_medical_bn
    bn = build_medical_bn()
    ev = {"Fever": True, "Cough": True, "Fatigue": True, "Breathing": True}
    covid_p = bn.query("COVID", evidence=ev)[True]
    flu_p   = bn.query("Flu",   evidence=ev)[True]
    assert covid_p > flu_p, \
        "COVID should be more likely than Flu when all 4 symptoms present"
    print("  [✓] test_medical_all_symptoms_covid_dominant")


# ──────────────────────────────────────────────────────────────────────────────
# Runner
# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("\n" + "=" * 50)
    print("  Running Bayesian Network Tests")
    print("=" * 50)

    print("\n[Factor tests]")
    test_factor_get()
    test_factor_restrict()
    test_factor_multiply()
    test_factor_marginalise()
    test_factor_normalise()

    print("\n[Burglary-Alarm BN tests]")
    test_prior_query()
    test_posterior_sums_to_one()
    test_alarm_evidence_raises_burglary()
    test_joint_probability()

    print("\n[Medical Diagnosis BN tests]")
    test_medical_breathing_increases_covid()
    test_medical_all_symptoms_covid_dominant()

    print("\n" + "=" * 50)
    print("  All tests passed ✓")
    print("=" * 50)
